import React from "react";

const generateMatrix = () => {
  const rows = 8;
  const cols = 8;
  const matrix = [];

  for (let i = 0; i < rows; i++) {
    const row = [];
    for (let j = 0; j < cols; j++) {
      const value = rows - i + j + 1;
      const color = `bg-${(i + j) % 2 === 0 ? "blue" : "purple"}-200`;
      row.push({ value, color });
    }
    matrix.push(row);
  }

  return matrix;
};

const RiskMatrix = () => {
  const matrix = generateMatrix();

  return (
    <div className="grid grid-cols-8 gap-1">
      {matrix.map((row, rowIndex) =>
        row.map((cell, colIndex) => (
          <div
            key={`${rowIndex}-${colIndex}`}
            className={`p-4 ${cell.color} border border-gray-400`}
          >
            {cell.value}
          </div>
        ))
      )}
    </div>
  );
};

export default RiskMatrix;
