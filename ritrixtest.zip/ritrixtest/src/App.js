import React from "react";
import RiskMatrix from "./RiskMatrix";
import "./App.css";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1 className="text-2xl font-bold">Risk Matrix</h1>
        <RiskMatrix />
      </header>
    </div>
  );
}

export default App;
